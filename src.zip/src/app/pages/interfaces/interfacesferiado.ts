
export interface RespuestaToHeadLines{
    status: string;
    data:Data[];
}

export interface Data{
    date:string;
    title:string;
    type:string;
    inalienable:boolean;
    extra:string;
}