import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api-taller.service';
import { Data } from '../interfaces/interfacesferiado';

@Component({
  selector: 'app-feriado',
  templateUrl: './feriado.page.html',
  styleUrls: ['./feriado.page.scss'],
})
export class FeriadoPage implements OnInit {

  feriados: Data[]=[];



  constructor(private menuController: MenuController,
    private apiservice: ApiService) { }

  ngOnInit() {
    this.apiservice.getTopHeadLines().subscribe(resp => {
      console.log(resp);
      this.feriados.push(...resp.data);
    })
  }


  mostrarMenu() {
    this.menuController.open('first');
  }
}
